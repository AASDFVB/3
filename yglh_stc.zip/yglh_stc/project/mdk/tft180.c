

#include "camer.h"
#include "INIT.h"
#include "fuzzy.h"
#include "motor.h"
#include "steer.h"
#include "tft180.h"


extern int16 speed1;
extern int16 speed2;
extern int16 Speed_Goal_l;
extern int16 Speed_Goal_r;
extern int Speed_Goal;
int jishu=0;
extern int run_flag;
extern float variance_acc;


void drawleftline()
{
    int x;
	int i;
     for(i=0;i<=59;i+=1)
     {
        x=ImageDeal[i].LeftBorder;
        tft180_draw_point(x,i,RGB565_RED);
     }
}

void drawrightline()
{
    int x;
	int i;
      for( i=0;i<=59;i+=1)
      {
          x=ImageDeal[i].RightBorder;
          tft180_draw_point(x,i,RGB565_RED);
      }
}

void drawcenterline()
{
    int x;
	int i;
     for( i=0;i<=58;i+=1)
     {
         x = (ImageDeal[i].RightBorder + ImageDeal[i].LeftBorder)/2;
        tft180_draw_point(x,i,RGB565_BLUE);
         
         if(jishu<=58)
         {
          wireless_uart_send_byte(x);
          jishu++;
         }

     }
}

void drawoffline()
{
    int x;
	int i;
     for(i=0;i<=79;i+=1)
     {
         x=ImageStatus.OFFLine;
         tft180_draw_point(i,x,RGB565_RED);
     }
}

void drawtowpointUP()
{
    int x;
	int i;
      for( i=0;i<=79;i+=1)
      {
          x=ImageStatus.TowPoint-5;
          tft180_draw_point(i,x,RGB565_CYAN);
      }
}

void drawtowpointDOWN()
{
      int x;
	int i;
      for(i=0;i<=79;i+=1)
      {
          x=ImageStatus.TowPoint+5;
          tft180_draw_point(i,x,RGB565_CYAN);
      }
}
void tft180()
{  
   

    tft180_show_gray_image(0,0,Pixle[0],LCDW,LCDH,LCDW,LCDH,1);             //��ֵ��ͼ��
    drawleftline();     //�������
    drawrightline();    //���ұ���
    drawcenterline();   //������
    drawoffline();      //��ͼ�񶥱�
    drawtowpointUP();   //��ǰհ��Χ����
    drawtowpointDOWN(); //��ǰհ��Χ����
}