#ifndef __motor_H_
#define __motor_H_
#include "zf_common_headfile.h"
#include "camer.h"

void Control_Speed();
void speed_measure(void);
void MOTOR_init(void);
void Encoder_init(void);
void Speed_decision(void);
void speed_PIDL(void);
void speed_PIDR(void);


typedef struct {
  float P;
  float I;
  float D;
  int LastError;  // Error[-1]
  int PrevError;  // Error[-2]
} PID_Datatypedef;

extern float Speed_P_l,Speed_I_l,Speed_D_l;
extern float Speed_P_r,Speed_I_r,Speed_D_r;
extern int run_flag;
extern PID_Datatypedef SteerPIDdata;    //�����PID����

#endif /* MOTOR_H_ */
















